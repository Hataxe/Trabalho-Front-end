// Script do site da Clinica Sorriso Leve
// Aqui fica o agendamento das consultas

// pegando os elementos da pagina
var form = document.getElementById("form-agendamento");
var campoNome = document.getElementById("nome");
var campoTelefone = document.getElementById("telefone");
var campoServico = document.getElementById("servico");
var campoData = document.getElementById("data");
var campoHorario = document.getElementById("horario");
var campoObservacoes = document.getElementById("observacoes");
var lista = document.getElementById("lista-agendamentos");
var mensagem = document.getElementById("mensagem");

// nome que vai ser usado para salvar no navegador
var chave = "sorrisoLeveAgendamentos";

// horarios que a clinica atende
var horarios = ["08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00", "17:00"];


// pega a data de hoje no formato aaaa-mm-dd
function pegarDataHoje() {
  var agora = new Date();
  var fuso = agora.getTimezoneOffset();
  var hoje = new Date(agora.getTime() - fuso * 60000);
  var texto = hoje.toISOString();
  return texto.slice(0, 10);
}

// nao deixa escolher data que ja passou
campoData.min = pegarDataHoje();


// pega os agendamentos que estao salvos
function pegarAgendamentos() {
  var salvo = localStorage.getItem(chave);
  if (salvo == null || salvo == "") {
    salvo = "[]";
  }
  return JSON.parse(salvo);
}

// salva os agendamentos no navegador
function salvarAgendamentos(agendamentos) {
  localStorage.setItem(chave, JSON.stringify(agendamentos));
}


// mostra so os horarios que estao livres no dia escolhido
function atualizarHorarios() {
  var dataEscolhida = campoData.value;

  campoHorario.innerHTML = '<option value="">Selecione um horário</option>';

  if (dataEscolhida == "") {
    return;
  }

  // 0 = domingo e 6 = sabado
  var dia = new Date(dataEscolhida + "T12:00:00").getDay();
  if (dia == 0 || dia == 6) {
    campoHorario.innerHTML = '<option value="">A clínica não atende aos fins de semana</option>';
    return;
  }

  // descobre quais horarios ja estao ocupados
  var agendamentos = pegarAgendamentos();
  var ocupados = [];
  for (var i = 0; i < agendamentos.length; i++) {
    if (agendamentos[i].data == dataEscolhida) {
      ocupados.push(agendamentos[i].horario);
    }
  }

  // coloca no select os que nao estao ocupados
  for (var j = 0; j < horarios.length; j++) {
    if (ocupados.indexOf(horarios[j]) == -1) {
      var opcao = document.createElement("option");
      opcao.value = horarios[j];
      opcao.textContent = horarios[j];
      campoHorario.appendChild(opcao);
    }
  }

  // se so sobrou a primeira opcao entao nao tem horario
  if (campoHorario.options.length == 1) {
    campoHorario.innerHTML = '<option value="">Não há horários disponíveis</option>';
  }
}


// deixa a data no formato dd/mm/aaaa
function formatarData(data) {
  var d = new Date(data + "T12:00:00");
  return d.toLocaleDateString("pt-BR");
}


// cancela um agendamento
function cancelarAgendamento(id) {
  var agendamentos = pegarAgendamentos();
  var novos = [];
  for (var i = 0; i < agendamentos.length; i++) {
    if (agendamentos[i].id != id) {
      novos.push(agendamentos[i]);
    }
  }
  salvarAgendamentos(novos);
  mostrarAgendamentos();
  atualizarHorarios();
}

// cria o quadradinho de um agendamento na lista
function criarItem(item) {
  var card = document.createElement("article");
  card.className = "agendamento-item";

  var detalhes = document.createElement("div");

  var nome = document.createElement("strong");
  nome.textContent = item.nome;

  var info = document.createElement("small");
  info.textContent = item.servico + " • " + formatarData(item.data) + " às " + item.horario + " • " + item.telefone;

  detalhes.appendChild(nome);
  detalhes.appendChild(info);

  var botao = document.createElement("button");
  botao.className = "remover";
  botao.type = "button";
  botao.textContent = "Cancelar";
  botao.setAttribute("aria-label", "Cancelar agendamento de " + item.nome);
  botao.onclick = function () {
    cancelarAgendamento(item.id);
  };

  card.appendChild(detalhes);
  card.appendChild(botao);
  lista.appendChild(card);
}

// mostra todos os agendamentos na tela
function mostrarAgendamentos() {
  var agendamentos = pegarAgendamentos();

  // coloca em ordem de data e horario
  agendamentos.sort(function (a, b) {
    var textoA = a.data + a.horario;
    var textoB = b.data + b.horario;
    return textoA.localeCompare(textoB);
  });

  lista.innerHTML = "";

  if (agendamentos.length == 0) {
    lista.innerHTML = '<p class="vazio">Nenhum agendamento por enquanto.</p>';
    return;
  }

  for (var i = 0; i < agendamentos.length; i++) {
    criarItem(agendamentos[i]);
  }
}


// quando muda a data atualiza os horarios
campoData.addEventListener("change", atualizarHorarios);

// quando clica em confirmar agendamento
form.addEventListener("submit", function (event) {
  event.preventDefault();
  mensagem.textContent = "";

  // confere se os campos estao preenchidos
  if (!form.reportValidity()) {
    return;
  }

  var novo = {
    id: Date.now(),
    nome: campoNome.value.trim(),
    telefone: campoTelefone.value.trim(),
    servico: campoServico.value,
    data: campoData.value,
    horario: campoHorario.value,
    observacoes: campoObservacoes.value.trim()
  };

  // confere se nao e fim de semana
  var dia = new Date(novo.data + "T12:00:00").getDay();
  if (dia == 0 || dia == 6) {
    mensagem.textContent = "Selecione um dia de segunda a sexta-feira.";
    return;
  }

  // confere se o horario ja foi ocupado
  var agendamentos = pegarAgendamentos();
  var ocupado = false;
  for (var i = 0; i < agendamentos.length; i++) {
    if (agendamentos[i].data == novo.data && agendamentos[i].horario == novo.horario) {
      ocupado = true;
    }
  }

  if (ocupado == true) {
    mensagem.textContent = "Esse horário acabou de ser ocupado. Escolha outro.";
    atualizarHorarios();
    return;
  }

  // salva o novo agendamento
  agendamentos.push(novo);
  salvarAgendamentos(agendamentos);

  mensagem.textContent = "Agendamento registrado neste navegador!";

  // limpa o formulario
  form.reset();
  campoData.min = pegarDataHoje();
  campoHorario.innerHTML = '<option value="">Escolha a data primeiro</option>';

  mostrarAgendamentos();
});

// mostra os agendamentos quando abre a pagina
mostrarAgendamentos();
