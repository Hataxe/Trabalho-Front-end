// Etapa 1 de 3 — base do projeto.
// Aqui só definimos a menor data permitida no campo de data (hoje).

const campoData = document.querySelector("#data");

function dataLocalISO() {
  const agora = new Date();
  const fuso = agora.getTimezoneOffset();
  return new Date(agora.getTime() - fuso * 60000).toISOString().slice(0, 10);
}

campoData.min = dataLocalISO();

// TODO (etapa 2): gerar os horários disponíveis conforme a data escolhida
//                 e bloquear fins de semana.
// TODO (etapa 2): salvar o agendamento no localStorage ao enviar o formulário.
// TODO (etapa 3): listar os agendamentos e permitir o cancelamento.
