# Clínica Sorriso Leve

Projeto acadêmico de agendamento odontológico feito com HTML, CSS e JavaScript puro.

**Status: etapa 1 de 3 concluída.**

## Como executar
1. Extraia a pasta `clinica-odontologica`.
2. Abra o arquivo `index.html` no navegador (ou use o Live Server no Visual Studio Code).

## Etapas do projeto
- [x] **Etapa 1 — Estrutura e visual:** página com cabeçalho, apresentação, serviços, layout do formulário e rodapé, responsiva para celular.
- [ ] **Etapa 2 — Agendamento:** horários por data, bloqueio de fins de semana, validação e salvamento no `localStorage`.
- [ ] **Etapa 3 — Gerenciamento:** lista de agendamentos, cancelamento e bloqueio de horários já ocupados.

## Situação atual
O formulário já existe visualmente, mas o botão de confirmar e a escolha de horário ainda estão desativados, pois dependem da etapa 2.
